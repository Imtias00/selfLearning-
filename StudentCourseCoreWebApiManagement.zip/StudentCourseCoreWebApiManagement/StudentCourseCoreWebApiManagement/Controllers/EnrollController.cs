﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using StudentCourseCoreWebApiManagement.Data;
using StudentCourseCoreWebApiManagement.Dto;
using StudentCourseCoreWebApiManagement.Models;

namespace StudentCourseCoreWebApiManagement.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class EnrollController : ControllerBase
    {
        private readonly StudentApiDbContext _context;
        public EnrollController(StudentApiDbContext context)
        {
            _context = context;
        }
        [HttpGet]
        public ActionResult<IEnumerable<Enroll>> Get()
        {
            return _context.Enrolls.ToList();
        }
        [HttpPost]
        public ActionResult<Enroll> AddEnroll(EnrollDto enrollDto)
        {
            var enrollment = new Enroll
            {
                StudentId = enrollDto.StudentId,
                CourseId = enrollDto.CourseId,
                EnrollmentTime = DateTime.Now,
                IsComplete = true
            };
            _context.Enrolls.Add(enrollment);
            _context.SaveChanges();
            if(enrollment.IsComplete)
            {
                var course = _context.Cases.Find(enrollDto.CourseId);
                var student = _context.Students.Find(enrollDto.StudentId);
                course.students ??=new List<Student>();
                course.students.Add(student);
                _context.SaveChanges();

                _context.SaveChanges();

                student.courses ??= new List<Course>();
                student.courses.Add(course);
                _context.SaveChanges();

                _context.SaveChanges();
            }
            return enrollment;
        }
    }
}
