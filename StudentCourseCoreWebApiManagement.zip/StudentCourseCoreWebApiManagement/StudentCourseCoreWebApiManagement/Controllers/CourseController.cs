﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using StudentCourseCoreWebApiManagement.Data;
using StudentCourseCoreWebApiManagement.Models;
using StudentCourseCoreWebApiManagement.Dto;

namespace StudentCourseCoreWebApiManagement.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class CourseController : ControllerBase
    {
        private readonly StudentApiDbContext _context;
        public CourseController(StudentApiDbContext context)
        {
            _context = context;
        }
        [HttpGet]
        public ActionResult<IEnumerable<Course>> Get()
        {
            return _context.Cases.Include(s => s.students).ToList();
        }
        [HttpGet("courses/{courseId}")]
        public ActionResult<Course> Get(int courseId)
        {
            var course = _context.Cases
                .Include(c => c.students)
                .FirstOrDefault(c => c.CourseId == courseId);
            if(course == null)
            {
                return NotFound();
            }
            return course;
        }
        [HttpGet("course/{courseName}")]
        public ActionResult<Course> GetName(string courseName)
        {
            var course = _context.Cases
                .Include(c => c.students)
                .FirstOrDefault(c => c.CourseName == courseName);
            if (course == null)
            {
                return NotFound();
            }
            return course;
        }
        
        [HttpPost]
        public ActionResult<Course> AddCourse(CourseDto courseDto)
        {
            var course = new Course
            {
                CourseName = courseDto.CourseName
            };
            _context.Cases.Add(course);
            _context.SaveChanges();
            return course;
        }
        [HttpPut("courses/{courseId}")]
        public ActionResult<Course> UpdateCourse(int courseId, CourseDto courseDto)
        {
            var course = _context.Cases.Find(courseId);
            if(course!= null){
                course.CourseName = courseDto.CourseName;
                _context.SaveChanges();
                return course;
            }
            return NotFound();
        }
    }
}
