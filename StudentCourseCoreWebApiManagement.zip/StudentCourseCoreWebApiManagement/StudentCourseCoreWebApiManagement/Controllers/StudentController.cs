﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using StudentCourseCoreWebApiManagement.Data;
using StudentCourseCoreWebApiManagement.Dto;
using StudentCourseCoreWebApiManagement.Models;

namespace StudentCourseCoreWebApiManagement.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class StudentController : ControllerBase
    {
        private readonly StudentApiDbContext _context;

        public StudentController(StudentApiDbContext context)
        {
            _context = context;
        }
        [HttpGet]
        public ActionResult<IEnumerable<Student>> Get()
        {
            return _context.Students.Include(s=> s.courses).ToList();
        }

        [HttpGet("students/{studentId}")]
        public ActionResult<Student> Get(int studentId) 
        {
            var student = _context.Students
                .Include(s => s.courses)
                .FirstOrDefault(s => s.StudnetId == studentId);
            if(student ==null)
            {
                return NotFound();
            }
            return student;
        }
        [HttpPost]
        public ActionResult<Student> Add(StudentDto studentDto)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }
            try
            {
                var student = new Student
                {
                    StudentName = studentDto.StudentName,
                    StudetAddress = studentDto.StudetAddress,
                    StudentEmail = studentDto.StudentEmail,
                    Phone = studentDto.Phone,
                };
                _context.Students.Add(student);
                _context.SaveChanges();
                return student;
            }
            catch (DbUpdateException ex)
            {
                // Log the exception or handle it as needed
                return StatusCode(500, "An error occurred while saving to the database");
            }
        }
        [HttpPut("students/{studentId}")]
        public ActionResult<Student> UpdateStudents(int studentId,StudentDto studentDto) {
            var student = _context.Students.Find(studentId);
            if(student != null)
            {
                student.StudentName = studentDto.StudentName;
                student.StudetAddress = studentDto.StudetAddress;
                student.StudentEmail = studentDto.StudentEmail;
                student.Phone = studentDto.Phone;
                _context.SaveChanges();
                return student;
            }
            return NotFound();
        }
    }
}
