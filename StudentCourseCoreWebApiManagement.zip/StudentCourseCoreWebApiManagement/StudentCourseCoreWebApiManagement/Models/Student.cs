﻿using System.ComponentModel.DataAnnotations;
using Microsoft.EntityFrameworkCore;
namespace StudentCourseCoreWebApiManagement.Models
{
    public class Student
    {
        [Key]
        public int StudnetId { get; set; }
        public string StudentName { get; set; }
        public string StudetAddress { get; set; }
        public string StudentEmail { get; set; }
        public int Phone {  get; set; }
        public ICollection<Course> courses { get; set; }

    }
}
