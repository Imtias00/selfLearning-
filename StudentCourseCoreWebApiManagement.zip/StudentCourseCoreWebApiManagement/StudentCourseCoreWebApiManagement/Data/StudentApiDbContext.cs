﻿using Microsoft.EntityFrameworkCore;
using StudentCourseCoreWebApiManagement.Models;
using System.Collections.Generic;
using System.Reflection.Emit;
namespace StudentCourseCoreWebApiManagement.Data
{
    public class StudentApiDbContext: DbContext
    {
        public StudentApiDbContext(DbContextOptions<StudentApiDbContext> options) : base(options)
        {

        }
        public DbSet<Student> Students { get; set; }
        public DbSet<Course> Cases { get; set; }
        public DbSet<Enroll> Enrolls { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Enroll>()
                .HasKey(e => e.EnrollId);
            modelBuilder.Entity<Enroll>()
                .HasOne(e => e.Student)
                .WithMany()
                .HasForeignKey(e => e.StudentId);
            modelBuilder.Entity<Enroll>()
                .HasOne(e => e.Course)
                .WithMany()
                .HasForeignKey(e => e.CourseId);
        }

    }
}
