﻿namespace StudentCourseCoreWebApiManagement.Dto
{
    public class EnrollDto
    {
        public int StudentId { get; set; }
        public int CourseId { get; set; }
    }
}
