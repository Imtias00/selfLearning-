﻿using System.ComponentModel.DataAnnotations;

namespace StudentCourseCoreWebApiManagement.Dto
{
    public class StudentDto
    {
        [Required(ErrorMessage = "StudentName is required")]
        public string StudentName { get; set; }

        [Required(ErrorMessage = "StudetAddress is required")]
        public string StudetAddress { get; set; }

        [Required(ErrorMessage = "StudentEmail is required")]
        [EmailAddress(ErrorMessage = "Invalid email format")]
        public string StudentEmail { get; set; }

        [Required(ErrorMessage = "Phone is required")]
        public int Phone { get; set; }
    }
}
