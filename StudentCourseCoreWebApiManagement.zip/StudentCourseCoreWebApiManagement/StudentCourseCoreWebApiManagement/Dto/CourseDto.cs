﻿namespace StudentCourseCoreWebApiManagement.Dto
{
    public class CourseDto
    {
        public string CourseName { get; set; }
    }
}
